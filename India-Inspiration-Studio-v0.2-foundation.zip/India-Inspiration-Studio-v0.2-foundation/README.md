# India Inspiration Studio — v0.2 Foundation Candidate

A premium, mobile-first English–Gujarati daily greeting-card generator.

## Current build

- Full 365-row working dataset embedded in the candidate
- Seven premium palettes
- Five composition styles
- Cultural-context-aware placeholder hero rendering
- English + Gujarati text fitting
- Editable footer name (`Dr. Atul`)
- Stale-download prevention
- 1080 × 1350 PNG export
- Offline PWA foundation
- “Why this day?” placeholder panel
- Dataset validator

## Status

This is a **foundation candidate**, not a final release.

The festival calendar and all Gujarati messages still require systematic source verification and spoken-Gujarati editorial review before production approval.

## Validate

```powershell
node --check .\tests\dataset-validation.js
node .\tests\dataset-validation.js
```

## Preview

```powershell
python -m http.server 8000
```

Open `http://localhost:8000`.
