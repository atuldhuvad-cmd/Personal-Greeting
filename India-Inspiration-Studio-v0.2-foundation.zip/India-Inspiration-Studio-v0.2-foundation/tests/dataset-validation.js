const fs=require("fs");
const p=require("path").join(__dirname,"..","data","India_Inspiration_Studio_2026_365_Day_Content_WORKING.csv");
const raw=fs.readFileSync(p,"utf8").replace(/^\uFEFF/,"");
function parseCSV(s){let rows=[],row=[],v="",q=false;for(let i=0;i<s.length;i++){let c=s[i],n=s[i+1];if(q){if(c=='"'&&n=='"'){v+='"';i++}else if(c=='"')q=false;else v+=c}else if(c=='"')q=true;else if(c==","){row.push(v);v=""}else if(c=="\n"){row.push(v.replace(/\r$/,""));rows.push(row);row=[];v=""}else v+=c}if(v||row.length){row.push(v);rows.push(row)}return rows}
const a=parseCSV(raw),h=a.shift(),ix=Object.fromEntries(h.map((x,i)=>[x,i]));
const errors=[];if(a.length!==365)errors.push(`Expected 365 rows, got ${a.length}`);
const dates=new Set();
for(const r of a){const d=r[ix.Date];if(dates.has(d))errors.push(`Duplicate ${d}`);dates.add(d);
 if(!/^2026-\d{2}-\d{2}$/.test(d))errors.push(`Bad date ${d}`);
 if(!r[ix.Occasion_English]||!r[ix.Occasion_Gujarati]||!r[ix.Message_English]||!r[ix.Message_Gujarati])errors.push(`Blank required field ${d}`);
 if(!/[\u0A80-\u0AFF]/.test(r[ix.Occasion_Gujarati]+r[ix.Message_Gujarati]))errors.push(`Gujarati missing ${d}`);
}
const jan=a.find(r=>r[ix.Date]==="2026-01-01");
if(!["Global","Western"].includes(jan[ix.Cultural_Context]))errors.push("1 January must be Global or Western");
if(jan[ix.Illustration_Prompt].match(/diya|rangoli|temple/i)&&!jan[ix.Illustration_Prompt].match(/no diya/i))errors.push("1 January contains Indian-festival imagery");
if(errors.length){console.error(errors.join("\n"));process.exit(1)}
console.log(`PASS: ${a.length} unique rows; Gujarati Unicode present; 1 January cultural metadata valid.`);
