# India Inspiration Studio v0.4 Artwork Candidate

Implemented:
- Local PNG/JPEG/WebP hero artwork upload
- Cover-crop rendering
- Artwork zoom and vertical focus controls
- Artwork preview
- Artwork-aware stale-download prevention
- Current artwork integrity in PNG export
- Generated motif fallback
- 365-day dataset
- Seven palettes
- Five compositions
- Calendar, favorites, history and search
- 1080 × 1350 PNG export
- Offline PWA foundation

Status: development candidate, not final release.
