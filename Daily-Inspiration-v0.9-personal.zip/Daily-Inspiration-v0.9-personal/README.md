# Daily Inspiration v0.9 Personal Candidate

Personal-use, single-user, offline-first English–Gujarati daily greeting-card app.

- No user-facing project branding
- Personal signature/footer
- Local preferences
- Editable English and Gujarati messages
- Local artwork upload
- Native mobile sharing
- PNG download
- Backup/restore
- Favorites and history
