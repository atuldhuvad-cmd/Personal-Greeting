# India Inspiration Studio v0.7 Editable Messages Candidate

- Resizable English and Gujarati editors
- Character and line counters
- Live fit indicators
- Reset English / Gujarati
- Save custom messages per date
- Restore original dataset
- Local persistence
- Custom-message-aware stale-download prevention

Development candidate only.
