# Daily Inspiration v1.0 Personal Greetings Candidate

Added Personal Greeting module:
- Birthday
- Wedding anniversary
- Retirement
- Graduation
- Housewarming
- Vacation memories
- Family reunions
- New baby
- Thank you
- Get well soon
- Congratulations
- Achievement
- Custom occasion

Features:
- Recipient name, age, relationship and tone
- English/Gujarati/bilingual messages
- Editable titles and messages
- Personal photo upload
- Crop-style cover fit, zoom and vertical focus
- Multiple greeting designs
- PNG download
- Native mobile sharing
- Save greeting locally
