# India Inspiration Studio v0.5 Layout QA Candidate

Implemented:
- Automatic per-poster layout QA
- English/Gujarati overflow warnings
- Footer-name validation
- Canvas-dimension validation
- Full 365-day in-app QA
- QA report export to JSON
- Duplicate/date/Unicode/palette/style/message-length checks
- Artwork upload, zoom and focus
- Calendar, favorites, history and search
- Stale-download prevention
- 1080 × 1350 PNG export

Status: development candidate, not final release.
