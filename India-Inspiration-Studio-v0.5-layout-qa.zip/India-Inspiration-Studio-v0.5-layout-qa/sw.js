const CACHE="india-inspiration-v0-5-layout-qa";
const FILES=["./","./index.html","./manifest.webmanifest","./data/India_Inspiration_Studio_2026_365_Day_Content_WORKING_v0_3.csv"];
self.addEventListener("install",e=>{e.waitUntil(caches.open(CACHE).then(c=>c.addAll(FILES)));self.skipWaiting()});
self.addEventListener("activate",e=>{e.waitUntil(caches.keys().then(k=>Promise.all(k.filter(x=>x!==CACHE).map(x=>caches.delete(x)))));self.clients.claim()});
self.addEventListener("fetch",e=>e.respondWith(caches.match(e.request).then(r=>r||fetch(e.request))));
