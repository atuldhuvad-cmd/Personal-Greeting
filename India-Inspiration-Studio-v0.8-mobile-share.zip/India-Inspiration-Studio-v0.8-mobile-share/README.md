# India Inspiration Studio v0.8 Mobile Share Candidate

- Native mobile poster sharing
- English, Gujarati and bilingual caption copy
- PNG fallback download
- Export custom edits/favorites/signature
- Import custom edits backup
- Resizable message editors
- Custom-message persistence
- Stale-download and stale-share prevention

Development candidate only.
